class const:
    article_num_all  = 6  # 阅读文章
    video_num_all    = 6  # 观看视频
    article_time_all = 6  # 文章时长
    video_time_all   = 6  # 视频时长
    login_all        = 1  # 每日登陆
    daily_all        = 5  # 每日答题
    weekly_all       = 5  # 每周答题
    zhuanxiang_all   = 10 # 专项答题